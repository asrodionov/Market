package helpers;

public class DataClass {
    public static final String URL = "https://www.ozon.ru/";
    public static final int IMPLICITLY_TIMEOUT = 5;
    public static final int EXPLICIT_TIMEOUT = 5;
}
